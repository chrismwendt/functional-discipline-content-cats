(* Mathematica Init File *)

Get[ "WildCats`WildCats`"]