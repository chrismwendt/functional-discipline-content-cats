(* Paclet Info File *)

(* created 2013/12/23*)

Paclet[
    Name -> "WildCats",
    Version -> "0.70.0",
    MathematicaVersion -> "8+",
    Description -> "Category Theory with Mathematica",
    Creator -> "Alessandro Stecchina",
    Extensions -> 
        {
            {"Documentation", Language -> "English", MainPage -> "Guides/WildCats"}
        }
]


