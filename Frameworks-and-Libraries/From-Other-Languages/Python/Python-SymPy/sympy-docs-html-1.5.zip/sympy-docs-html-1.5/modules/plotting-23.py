PlotGrid(1, 3 , p2, p3, p4)
# PlotGrid object containing:
# Plot[0]:Plot object containing:
# [0]: cartesian line: x**2 for x over (-6.0, 6.0)
# [1]: cartesian line: x for x over (-5.0, 5.0)
# Plot[1]:Plot object containing:
# [0]: cartesian line: x**3 for x over (-5.0, 5.0)
# Plot[2]:Plot object containing:
# [0]: cartesian surface: x*y for x over (-5.0, 5.0) and y over (-5.0, 5.0)
