b.solve_for_reaction_loads(R, M)
b.reaction_loads
# {M: -258, R: 52}
b.load
# -2         -1        0             -2            0             -1
# - 258⋅<x>   + 52⋅<x>   - 8⋅<x>  + 50⋅<x - 5>   + 8⋅<x - 5>  - 12⋅<x - 9>
