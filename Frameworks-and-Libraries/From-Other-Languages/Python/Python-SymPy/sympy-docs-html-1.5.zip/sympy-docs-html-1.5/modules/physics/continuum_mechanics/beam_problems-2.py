from sympy.physics.continuum_mechanics.beam import Beam
E, I = symbols('E, I')
b = Beam(9, E, I)
