b.bc_deflection.append((0, 0))
b.bc_slope.append((0, 0))
