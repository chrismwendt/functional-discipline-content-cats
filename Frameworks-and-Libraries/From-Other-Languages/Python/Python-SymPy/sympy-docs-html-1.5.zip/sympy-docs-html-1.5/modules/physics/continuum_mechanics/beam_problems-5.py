b.apply_load(50, 5, -2)
