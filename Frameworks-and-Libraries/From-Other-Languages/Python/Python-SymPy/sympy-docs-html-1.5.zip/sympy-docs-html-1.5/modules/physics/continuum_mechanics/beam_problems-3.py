b.apply_load(-12, 9, -1)
