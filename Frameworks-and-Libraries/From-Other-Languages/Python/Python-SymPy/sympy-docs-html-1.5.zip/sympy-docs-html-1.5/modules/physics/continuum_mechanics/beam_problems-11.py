b.plot_shear_force()  # doctest: +SKIP
b.plot_bending_moment()  # doctest: +SKIP
