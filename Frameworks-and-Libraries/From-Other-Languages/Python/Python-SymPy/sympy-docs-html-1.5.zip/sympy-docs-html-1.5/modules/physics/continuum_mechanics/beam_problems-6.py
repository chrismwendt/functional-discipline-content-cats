b.apply_load(-8, 0, 0, end=5)
