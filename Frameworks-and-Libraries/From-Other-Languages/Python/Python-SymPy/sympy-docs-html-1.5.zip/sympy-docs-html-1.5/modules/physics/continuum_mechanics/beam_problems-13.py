b.plot_slope(subs={E: 20E9, I: 3.25E-6})  # doctest: +SKIP
b.plot_deflection(subs={E: 20E9, I: 3.25E-6})  # doctest: +SKIP
