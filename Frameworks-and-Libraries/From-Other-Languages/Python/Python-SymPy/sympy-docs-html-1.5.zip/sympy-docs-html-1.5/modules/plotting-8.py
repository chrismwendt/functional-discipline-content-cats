from sympy import symbols, cos, sin
from sympy.plotting import plot_parametric
u = symbols('u')
