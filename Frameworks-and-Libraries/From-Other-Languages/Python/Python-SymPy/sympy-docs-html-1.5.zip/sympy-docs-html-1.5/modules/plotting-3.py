from sympy import symbols
from sympy.plotting import plot
x = symbols('x')
