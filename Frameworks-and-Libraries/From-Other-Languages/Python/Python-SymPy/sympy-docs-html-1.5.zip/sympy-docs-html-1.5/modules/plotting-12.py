from sympy import symbols
from sympy.plotting import plot3d
x, y = symbols('x y')
