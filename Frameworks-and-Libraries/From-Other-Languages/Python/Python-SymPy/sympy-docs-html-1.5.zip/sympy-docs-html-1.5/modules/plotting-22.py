PlotGrid(2, 1 , p1, p2)
# PlotGrid object containing:
# Plot[0]:Plot object containing:
# [0]: cartesian line: x for x over (-5.0, 5.0)
# [1]: cartesian line: x**2 for x over (-5.0, 5.0)
# [2]: cartesian line: x**3 for x over (-5.0, 5.0)
# Plot[1]:Plot object containing:
# [0]: cartesian line: x**2 for x over (-6.0, 6.0)
# [1]: cartesian line: x for x over (-5.0, 5.0)
