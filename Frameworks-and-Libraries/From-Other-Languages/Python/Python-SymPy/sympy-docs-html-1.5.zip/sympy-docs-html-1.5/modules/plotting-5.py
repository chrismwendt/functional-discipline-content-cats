plot(x, x**2, x**3, (x, -5, 5))
# Plot object containing:
# [0]: cartesian line: x for x over (-5.0, 5.0)
# [1]: cartesian line: x**2 for x over (-5.0, 5.0)
# [2]: cartesian line: x**3 for x over (-5.0, 5.0)
