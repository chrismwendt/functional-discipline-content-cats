plot((x**2, (x, -6, 6)), (x, (x, -5, 5)))
# Plot object containing:
# [0]: cartesian line: x**2 for x over (-6.0, 6.0)
# [1]: cartesian line: x for x over (-5.0, 5.0)
