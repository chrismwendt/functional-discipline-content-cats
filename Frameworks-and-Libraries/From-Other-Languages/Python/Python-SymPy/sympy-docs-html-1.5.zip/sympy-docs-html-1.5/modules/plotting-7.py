plot(x**2, adaptive=False, nb_of_points=400)
# Plot object containing:
# [0]: cartesian line: x**2 for x over (-10.0, 10.0)
